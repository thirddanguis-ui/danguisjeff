<?php

namespace App\Models;

use CodeIgniter\Model;

class NetworkLogModel extends Model
{
    protected $table = 'network_logs';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'username', 'action', 'ip_address', 'mac_address', 'timestamp'
    ];

    // ❌ Disable automatic timestamp handling
    protected $useTimestamps = false;
}
