<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use App\Models\SettingsModel;

class MaintenanceFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $model = new SettingsModel();
        $status = $model->getMaintenanceStatus();

        $uri = service('uri');
        $segment = $uri->getSegment(1);

        // allow dashboard & auth pages only
        if ($status === 'on' && !in_array($segment, ['dashboard', 'auth'])) {
            echo view('maintenance_view');
            return false;
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
