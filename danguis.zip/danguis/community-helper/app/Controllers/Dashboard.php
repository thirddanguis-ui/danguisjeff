<?php

namespace App\Controllers;

use App\Models\ResidentModel;
use App\Models\RequestModel;
use App\Models\EventModel;
use App\Models\SettingsModel;

class Dashboard extends BaseController
{
    protected $settingsModel;

    public function __construct()
    {
        $this->settingsModel = new SettingsModel();
    }

    public function index()
    {
        $residentModel = new ResidentModel();
        $requestModel  = new RequestModel();
        $eventModel    = new EventModel();

        // ✅ Fetch counts
        $data['totalResidents'] = $residentModel->countAllResults();
        $data['totalRequests']  = $requestModel->countAllResults();
        $data['totalEvents']    = $eventModel->countAllResults();

        // ✅ Monthly events (for bar chart)
        $data['monthlyEvents'] = $eventModel
            ->select("MONTH(start_datetime) as month, COUNT(*) as count")
            ->groupBy("MONTH(start_datetime)")
            ->orderBy("month", "ASC")
            ->findAll();

        // ✅ Residents by gender (for pie chart)
        $data['residentsByGender'] = $residentModel
            ->select("gender, COUNT(*) as count")
            ->groupBy("gender")
            ->findAll();

        // ✅ Maintenance toggle status (from JSON file)
        $data['maintenance_status'] = $this->getMaintenanceStatus();

        return view('templates/header')
            . view('templates/sidebar')
            . view('dashboard/index', $data)
            . view('templates/footer');
    }

   private function getMaintenanceStatus()
{
    $file = WRITEPATH . 'maintenance_mode.json';
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        return $data['status'] ?? 'off';
    }
    return 'off';
}

public function toggleMaintenance()
{
    $status = $this->request->getPost('maintenance_mode') ? 'on' : 'off';
    file_put_contents(WRITEPATH . 'maintenance_mode.json', json_encode(['status' => $status]));
    return redirect()->to(base_url('dashboard'))->with('message', 'Maintenance mode updated.');
}

}
