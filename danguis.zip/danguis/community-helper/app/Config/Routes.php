<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::login'); // Redirect root to login page

$routes->get('register', 'Auth::register');
$routes->post('auth/login', 'Auth::login');
$routes->post('auth/store', 'Auth::store');
$routes->get('logout', 'Auth::logout');
$routes->get('dashboard', 'Dashboard::index', ['filter' => 'auth']);

// ✅ Add this POST route for toggling maintenance mode
$routes->post('dashboard/toggleMaintenance', 'Dashboard::toggleMaintenance', ['filter' => 'auth']);

$routes->group('', ['filter' => 'auth'], function($routes) {
    $routes->get('residents', 'Residents::index');
    $routes->get('residents/create', 'Residents::create');
    $routes->post('residents/store', 'Residents::store');
    $routes->get('residents/edit/(:num)', 'Residents::edit/$1');
    $routes->post('residents/update/(:num)', 'Residents::update/$1');
    $routes->get('residents/delete/(:num)', 'Residents::delete/$1');
});

$routes->get('/requests', 'Requests::index');
$routes->get('/requests/create', 'Requests::create');
$routes->post('/requests/store', 'Requests::store');
$routes->get('/requests/edit/(:num)', 'Requests::edit/$1');
$routes->post('/requests/update/(:num)', 'Requests::update/$1');
$routes->get('/requests/delete/(:num)', 'Requests::delete/$1');

$routes->get('/events', 'Events::index');
$routes->get('/events/create', 'Events::create');
$routes->post('/events/store', 'Events::store');
$routes->get('/events/edit/(:num)', 'Events::edit/$1');
$routes->post('/events/update/(:num)', 'Events::update/$1');
$routes->get('/events/delete/(:num)', 'Events::delete/$1');

$routes->get('/dashboard', 'Dashboard::index');


$routes->get('networklogs', 'NetworkLogs::index');
$routes->get('networklogs/clear', 'NetworkLogs::clear');
