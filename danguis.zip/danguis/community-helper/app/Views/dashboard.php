<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .sidebar {
      height: 100vh;
      width: 230px;
      position: fixed;
      background: #0d6efd;
      color: white;
      padding-top: 20px;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 10px 20px;
    }
    .sidebar a:hover {
      background: rgba(255,255,255,0.2);
    }
    .content {
      margin-left: 230px;
      padding: 20px;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h4 class="text-center mb-4">Community Helper</h4>
    <a href="<?= base_url('dashboard') ?>">🏠 Dashboard</a>
    <a href="<?= base_url('residents') ?>">👥 Residents</a>
    <a href="<?= base_url('requests') ?>">📝 Help Requests</a>
    <a href="<?= base_url('events') ?>">📅 Events</a>
    <a href="<?= base_url('networklogs') ?>">🌐 Network Logs</a>
    <a href="<?= base_url('logout') ?>">🚪 Logout</a>
  </div>

  <div class="content">
    <h3>Welcome, <?= session('username') ?> 👋</h3>
    <p>Select a menu from the sidebar.</p>
  </div>
</body>
</html>
