<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class UserAuth extends Controller
{
    public function register()
    {
        if (session()->get('user_id')) {
            return redirect()->to('/user/home');
        }

        return view('user/register');
    }

    public function store()
    {
        helper(['form']);

        $rules = [
            'username' => 'required|min_length[3]|is_unique[users.username]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'confirm_password' => 'matches[password]'
        ];

        if (! $this->validate($rules)) {
            return view('user/register', ['validation' => $this->validator]);
        }

        $model = new UserModel();
        $model->save([
            'username' => $this->request->getVar('username'),
            'email'    => $this->request->getVar('email'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT),
            'full_name' => $this->request->getVar('full_name'),
        ]);

        session()->setFlashdata('success', 'Registration successful. You can now log in.');
        return redirect()->to('/user/login');
    }

    public function login()
    {
        if (session()->get('user_id')) {
            return redirect()->to('/user/home');
        }
        return view('user/login');
    }

    public function authenticate()
    {
        helper(['form']);

        $rules = [
            'identity' => 'required',
            'password' => 'required'
        ];

        if (! $this->validate($rules)) {
            return view('user/login', ['validation' => $this->validator]);
        }

        $identity = $this->request->getVar('identity');
        $password = $this->request->getVar('password');

        $model = new UserModel();
        $user = $model->getByIdentity($identity);

        if ($user && password_verify($password, $user['password'])) {
            session()->set([
                'user_id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'isLoggedInUser' => true
            ]);
            return redirect()->to('/user/home');
        }

        session()->setFlashdata('error', 'Invalid login credentials.');
        return redirect()->back();
    }

    public function logout()
    {
        session()->remove(['user_id', 'username', 'email', 'isLoggedInUser']);
        return redirect()->to('/user/login');
    }

    public function home()
    {
        // protected user area
        if (! session()->get('isLoggedInUser')) {
            return redirect()->to('/user/login');
        }

        // Get maintenance status
        $file = WRITEPATH . 'maintenance_mode.json';
        $maintenance_status = 'off';
        if (file_exists($file)) {
            $data_file = json_decode(file_get_contents($file), true);
            $maintenance_status = $data_file['status'] ?? 'off';
        }

        // Get recent admin activity logs (limit to 5 for speed) with admin username
        $networkLogModel = new \App\Models\NetworkLogModel();
        $activityLogs = $networkLogModel
            ->select('network_logs.*, admins.username AS admin_name')
            ->join('admins', 'admins.id = network_logs.user_id', 'left')
            ->orderBy('network_logs.created_at', 'DESC')
            ->limit(5)
            ->findAll();

        $data['title'] = 'User Home';
        $data['maintenance_status'] = $maintenance_status;
        $data['activityLogs'] = $activityLogs;

        return view('templates/header', $data)
            . view('user/home', $data)
            . view('templates/footer');
    }
}
