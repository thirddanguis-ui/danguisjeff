<?php

namespace App\Controllers;

use App\Models\NetworkLogModel;
use App\Models\AdminModel;

class NetworkLogs extends BaseController
{
    protected $logModel;
    protected $adminModel;
    protected $session;

    public function __construct()
    {
        helper(['form', 'url', 'maintenance']);
        checkMaintenanceMode(); // ✅ Prevent access if under maintenance
        $this->logModel = new NetworkLogModel();
        $this->adminModel = new AdminModel();
        $this->session = session();
    }

    // 🧭 Show all logs inside dashboard layout
    public function index()
    {
        $data['title'] = 'Network Logs';
        $data['logs'] = $this->logModel
            ->select('network_logs.*, admins.username AS admin_name')
            ->join('admins', 'admins.id = network_logs.user_id', 'left')
            ->orderBy('network_logs.created_at', 'DESC')
            ->findAll();

        // ✅ Load with dashboard layout (sidebar + header)
        echo view('templates/header', $data);
        echo view('templates/sidebar');
        echo view('network_logs/index', $data);
        echo view('templates/footer');
    }

    // 🧹 Clear all logs
    public function clear()
    {
        $this->logModel->truncate();
        $this->session->setFlashdata('success', 'All network logs have been cleared.');
        return redirect()->to('/networklogs');
    }

    // 🖥️ Get Local IP (logActivity logic applied)
    public static function getLocalIpAddress()
    {
        $request = \Config\Services::request();
        $ip = $request->getIPAddress();
        return $ip ?? ($_SERVER['REMOTE_ADDR'] ?? 'Unknown');
    }

    // 🔍 Get MAC Address (logActivity logic applied)
    public static function getMacAddress()
    {
        $request = \Config\Services::request();
        $ip = $request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        return $mac;
    }

    // 📝 Record user activity (for audit trail)
    public static function record($userId, $action)
    {
        $logModel = new NetworkLogModel();
        $request = \Config\Services::request();
        $ip = $request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        $logModel->insert([
            'user_id'     => $userId,
            'action'      => $action,
            'ip_address'  => $ip,
            'mac_address' => $mac,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
    }
}
