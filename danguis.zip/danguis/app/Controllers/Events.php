<?php

namespace App\Controllers;

use App\Models\EventModel;
use App\Models\NetworkLogModel;
use CodeIgniter\Controller;

class Events extends Controller
{
    protected $helpers = ['form', 'url', 'maintenance'];
    protected $eventModel;
    protected $networkLogModel;

    public function __construct()
    {
        helper(['form', 'url', 'maintenance']);
        checkMaintenanceMode(); // ✅ Maintenance mode check
        $this->eventModel = new EventModel();
        $this->networkLogModel = new NetworkLogModel();
    }

    // ✅ Unified activity logger (uses existing columns only)
    private function logActivity($action, $eventName = '')
    {
        $ip = $this->request->getIPAddress();
        $mac = 'N/A';

        // Try to detect MAC address (works in LAN or local dev)
        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        // Include event name in action log text
        $actionText = $eventName ? "{$action}: {$eventName}" : $action;

        // ✅ Save log entry using existing columns only
        $this->networkLogModel->insert([
            'user_id'     => session()->get('admin_id') ?? null,
            'action'      => $actionText,
            'details'     => '',
            'ip_address'  => $ip,
            'mac_address' => $mac,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
    }

    // ✅ Display all events
    public function index()
    {
        $data['events'] = $this->eventModel->orderBy('start_datetime', 'ASC')->findAll();

        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('events/index', $data);
        echo view('templates/footer');
    }

    // ✅ Show create event form
    public function create()
    {
        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('events/create');
        echo view('templates/footer');
    }

    // ✅ Store new event + log activity with event name
    public function store()
    {
        $title = $this->request->getPost('title');
        $ip = $this->request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        $this->eventModel->save([
            'title'          => $title,
            'description'    => $this->request->getPost('description'),
            'location'       => $this->request->getPost('location'),
            'start_datetime' => $this->request->getPost('start_datetime'),
            'end_datetime'   => $this->request->getPost('end_datetime'),
            'ip_address'     => $ip,
            'mac_address'    => $mac,
        ]);

        // Log with event name
        $this->logActivity("Created event", $title);

        return redirect()->to('/events')->with(
            'success',
            "Event <b>$title</b> added successfully!<br>🖥 IP: <b>$ip</b><br>🪪 MAC: <b>$mac</b>"
        );
    }

    // ✅ Edit event form
    public function edit($id)
    {
        $data['event'] = $this->eventModel->find($id);

        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('events/edit', $data);
        echo view('templates/footer');
    }

    // ✅ Update event + log with name
    public function update($id)
    {
        $title = $this->request->getPost('title');
        $ip = $this->request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        $this->eventModel->update($id, [
            'title'          => $title,
            'description'    => $this->request->getPost('description'),
            'location'       => $this->request->getPost('location'),
            'start_datetime' => $this->request->getPost('start_datetime'),
            'end_datetime'   => $this->request->getPost('end_datetime'),
            'ip_address'     => $ip,
            'mac_address'    => $mac,
        ]);

        $this->logActivity("Updated event", $title);

        return redirect()->to('/events')->with(
            'success',
            "Event <b>$title</b> updated successfully!<br>🖥 IP: <b>$ip</b><br>🪪 MAC: <b>$mac</b>"
        );
    }

    // ✅ Delete event + log with name
    public function delete($id)
    {
        $event = $this->eventModel->find($id);

        if ($event) {
            $this->eventModel->delete($id);
            $this->logActivity("Deleted event", $event['title']);
        }

        return redirect()->to('/events')->with('success', 'Event deleted successfully!');
    }
}
