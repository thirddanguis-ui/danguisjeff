<?php

namespace App\Controllers;

use App\Models\HelperModel;
use CodeIgniter\Controller;

class Helpers extends Controller
{
    protected $helpers = ['form', 'url'];

    public function index()
    {
        $model = new HelperModel();
        $data['helpers'] = $model->findAll();

        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('helpers/index', $data);
        echo view('templates/footer');
    }

    public function create()
    {
        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('helpers/create');
        echo view('templates/footer');
    }

    public function store()
    {
        $model = new HelperModel();
        $model->save([
            'fullname' => $this->request->getPost('fullname'),
            'position' => $this->request->getPost('position'),
            'contact'  => $this->request->getPost('contact'),
            'email'    => $this->request->getPost('email'),
            'status'   => $this->request->getPost('status'),
        ]);

        return redirect()->to('/helpers');
    }

    public function edit($id)
    {
        $model = new HelperModel();
        $data['helper'] = $model->find($id);

        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('helpers/edit', $data);
        echo view('templates/footer');
    }

    public function update($id)
    {
        $model = new HelperModel();
        $model->update($id, [
            'fullname' => $this->request->getPost('fullname'),
            'position' => $this->request->getPost('position'),
            'contact'  => $this->request->getPost('contact'),
            'email'    => $this->request->getPost('email'),
            'status'   => $this->request->getPost('status'),
        ]);

        return redirect()->to('/helpers');
    }

    public function delete($id)
    {
        $model = new HelperModel();
        $model->delete($id);
        return redirect()->to('/helpers');
    }
}
