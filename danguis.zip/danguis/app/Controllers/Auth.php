<?php

namespace App\Controllers;

use App\Models\AdminModel;
use CodeIgniter\Controller;

class Auth extends Controller
{
    public function login()
    {
        // If already logged in, redirect to dashboard
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/dashboard');
        }
        return view('auth/login');
    }

    public function register()
    {
        return view('auth/register');
    }

    public function store()
    {
        helper(['form']);
        $rules = [
            'username' => 'required|min_length[3]|is_unique[admins.username]',
            'email'    => 'required|valid_email|is_unique[admins.email]',
            'password' => 'required|min_length[6]',
            'confirm_password' => 'matches[password]'
        ];

        if (!$this->validate($rules)) {
            return view('auth/register', [
                'validation' => $this->validator
            ]);
        }

        $adminModel = new AdminModel();
        $data = [
            'username' => $this->request->getVar('username'),
            'email'    => $this->request->getVar('email'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT),
            'full_name' => $this->request->getVar('full_name'),
        ];
        $adminModel->save($data);

        session()->setFlashdata('success', 'Admin registration successful! You may now log in.');
        return redirect()->to('admin/login');
    }

    public function authenticate()
    {
        helper(['form']);
        $rules = [
            'identity' => 'required',
            'password' => 'required'
        ];

        if (!$this->validate($rules)) {
            return view('auth/login', [
                'validation' => $this->validator
            ]);
        }

        $adminModel = new AdminModel();
        $identity = $this->request->getVar('identity');
        $password = $this->request->getVar('password');

        $admin = $adminModel->getByIdentity($identity);

        if ($admin && password_verify($password, $admin['password'])) {
            $sessionData = [
                'admin_id' => $admin['id'],
                'username' => $admin['username'],
                'email' => $admin['email'],
                'isLoggedIn' => true
            ];
            session()->set($sessionData);
            return redirect()->to('/dashboard');
        } else {
            session()->setFlashdata('error', 'Invalid admin login credentials.');
            return redirect()->back();
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
