<?php 

namespace App\Controllers;

use App\Models\RequestModel;
use App\Models\ResidentModel;
use App\Models\NetworkLogModel;
use CodeIgniter\Controller;

class Requests extends Controller
{
    protected $helpers = ['form', 'url', 'maintenance'];
    protected $residentModel;
    protected $requestModel;
    protected $networkLogModel;

    public function __construct()
    {
        helper(['form', 'url', 'maintenance']);
        checkMaintenanceMode();
        $this->residentModel = new ResidentModel();
        $this->requestModel = new RequestModel();
        $this->networkLogModel = new NetworkLogModel();
    }

    private function getIPAddress()
    {
        $ip = $this->request->getIPAddress();
        return $ip ?? ($_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN');
    }

    private function getMACAddress()
    {
        $ip = $this->request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = strtoupper($matches[0]);
        }

        return $mac;
    }

    private function logNetworkActivity($action)
    {
        $ip = $this->getIPAddress();
        $mac = $this->getMACAddress();

        $this->networkLogModel->insert([
            'user_id'     => session('admin_id') ?? null,
            'action'      => $action,
            'ip_address'  => $ip,
            'mac_address' => $mac,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
    }

    public function index()
    {
        $data['requests'] = $this->requestModel->findAll();

        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('requests/index', $data);
        echo view('templates/footer');
    }

    public function create()
    {
        $data['residents'] = $this->residentModel->findAll();

        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('requests/create', $data);
        echo view('templates/footer');
    }

    public function store()
    {
        $ip = $this->getIPAddress();
        $mac = $this->getMACAddress();

        // ✅ Validate resident_id safely without altering DB
        $residentId = $this->request->getPost('resident_id');
        if (!$residentId || !$this->residentModel->find($residentId)) {
            $residentId = null;
        }

        $this->requestModel->save([
            'resident_id' => $residentId,
            'title'       => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'priority'    => $this->request->getPost('priority'),
            'status'      => $this->request->getPost('status'),
            'assigned_to' => $this->request->getPost('assigned_to'),
            'ip_address'  => $ip,
            'mac_address' => $mac,
        ]);

        $this->logNetworkActivity("Created help request: " . $this->request->getPost('title'));

        return redirect()->to('/requests')->with(
            'success',
            "Request added successfully!<br>🖥 IP: <b>$ip</b><br>🪪 MAC: <b>$mac</b>"
        );
    }

    public function edit($id)
    {
        $data['request'] = $this->requestModel->find($id);
        $data['residents'] = $this->residentModel->findAll();

        echo view('templates/header');
        echo view('templates/sidebar');
        echo view('requests/edit', $data);
        echo view('templates/footer');
    }

    public function update($id)
    {
        $ip = $this->getIPAddress();
        $mac = $this->getMACAddress();

        $residentId = $this->request->getPost('resident_id');
        if (!$residentId || !$this->residentModel->find($residentId)) {
            $residentId = null;
        }

        $this->requestModel->update($id, [
            'resident_id' => $residentId,
            'title'       => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'priority'    => $this->request->getPost('priority'),
            'status'      => $this->request->getPost('status'),
            'assigned_to' => $this->request->getPost('assigned_to'),
            'ip_address'  => $ip,
            'mac_address' => $mac,
        ]);

        $this->logNetworkActivity("Updated help request: " . $this->request->getPost('title'));

        return redirect()->to('/requests')->with(
            'success',
            "Request updated successfully!<br>🖥 IP: <b>$ip</b><br>🪪 MAC: <b>$mac</b>"
        );
    }

    public function delete($id)
    {
        $request = $this->requestModel->find($id);

        if ($request) {
            $this->requestModel->delete($id);
            $this->logNetworkActivity("Deleted help request: " . $request['title']);
        }

        return redirect()->to('/requests')->with('success', 'Request deleted successfully!');
    }
}
