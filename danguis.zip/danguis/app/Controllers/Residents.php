<?php

namespace App\Controllers;

use App\Models\ResidentModel;
use App\Controllers\NetworkLogs; // ✅ Import NetworkLogs for recording

class Residents extends BaseController
{
    protected $residentModel;

    public function __construct()
    {
        helper(['form', 'url', 'maintenance']);
        checkMaintenanceMode();
        $this->residentModel = new ResidentModel();
    }

    // ✅ Display all residents
    public function index()
    {
        $data['title'] = 'Residents';
        $data['residents'] = $this->residentModel->findAll();
        echo view('templates/header', $data);
        echo view('templates/sidebar');
        echo view('residents/index', $data);
        echo view('templates/footer');
    }

    // ✅ Show Add Resident Form
    public function create()
    {
        $data['title'] = 'Add Resident';
        echo view('templates/header', $data);
        echo view('templates/sidebar');
        echo view('residents/create');
        echo view('templates/footer');
    }

    // ✅ Save new resident with IP and MAC logging (logActivity logic applied)
    public function store()
    {
        $ip = $this->request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        $this->residentModel->save([
            'first_name'  => $this->request->getPost('first_name'),
            'last_name'   => $this->request->getPost('last_name'),
            'address'     => $this->request->getPost('address'),
            'phone'       => $this->request->getPost('phone'),
            'email'       => $this->request->getPost('email'),
            'gender'      => $this->request->getPost('gender'),
            'birthdate'   => $this->request->getPost('birthdate'),
            'ip_address'  => $ip,
            'mac_address' => $mac,
        ]);

        $adminId = session('admin_id') ?? 0;
        NetworkLogs::record($adminId, "Added new resident: " . $this->request->getPost('first_name') . " " . $this->request->getPost('last_name'));

        return redirect()->to('/residents')->with('success', "Resident added successfully!<br>🖥 IP: <b>$ip</b><br>🪪 MAC: <b>$mac</b>");
    }

    // ✅ Edit Resident
    public function edit($id)
    {
        $data['title'] = 'Edit Resident';
        $data['resident'] = $this->residentModel->find($id);
        echo view('templates/header', $data);
        echo view('templates/sidebar');
        echo view('residents/edit', $data);
        echo view('templates/footer');
    }

    // ✅ Update Resident with IP & MAC (logActivity logic applied)
    public function update($id)
    {
        $ip = $this->request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        $this->residentModel->update($id, [
            'first_name'  => $this->request->getPost('first_name'),
            'last_name'   => $this->request->getPost('last_name'),
            'address'     => $this->request->getPost('address'),
            'phone'       => $this->request->getPost('phone'),
            'email'       => $this->request->getPost('email'),
            'gender'      => $this->request->getPost('gender'),
            'birthdate'   => $this->request->getPost('birthdate'),
            'ip_address'  => $ip,
            'mac_address' => $mac,
        ]);

        $adminId = session('admin_id') ?? 0;
        NetworkLogs::record($adminId, "Updated resident ID #$id");

        return redirect()->to('/residents')->with('success', "Resident updated successfully!<br>🖥 IP: <b>$ip</b><br>🪪 MAC: <b>$mac</b>");
    }

    // ✅ Delete Resident (logActivity logic applied)
    public function delete($id)
    {
        $resident = $this->residentModel->find($id);

        $ip = $this->request->getIPAddress();
        $mac = 'N/A';

        if (stripos(PHP_OS, 'WIN') === 0) {
            $output = shell_exec("arp -a $ip");
        } else {
            $output = shell_exec("arp -n $ip");
        }

        if ($output && preg_match('/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i', $output, $matches)) {
            $mac = $matches[0];
        }

        $this->residentModel->delete($id);

        $adminId = session('admin_id') ?? 0;
        $residentName = $resident ? $resident['first_name'] . ' ' . $resident['last_name'] : 'Unknown';
        NetworkLogs::record($adminId, "Deleted resident: $residentName (ID #$id)");

        return redirect()->to('/residents')->with('success', "Resident deleted successfully!<br>🖥 IP: <b>$ip</b><br>🪪 MAC: <b>$mac</b>");
    }
}
