<?php

namespace App\Controllers;

use App\Models\RequestModel;
use App\Models\ResidentModel;

class PublicUser extends BaseController
{
    protected $requestModel;
    protected $residentModel;

    public function __construct()
    {
        helper('maintenance');
        // public users are subject to maintenance mode
        checkMaintenanceMode();

        $this->requestModel = new RequestModel();
        $this->residentModel = new ResidentModel();
    }

    // Public listing of help requests (minimal info)
    public function index()
    {
        // fetch latest requests with resident basic info
        $requests = $this->requestModel
            ->select('requests.*, residents.first_name, residents.last_name, residents.phone, residents.email')
            ->join('residents', 'residents.id = requests.resident_id', 'left')
            ->orderBy('requests.id', 'DESC')
            ->findAll(20);

        $data['title'] = 'Public - Help Requests';
        $data['requests'] = $requests;

        echo view('templates/header', $data);
        echo view('public/index', $data);
        echo view('templates/footer');
    }
}
