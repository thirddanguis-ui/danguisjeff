<?php

namespace App\Models;

use CodeIgniter\Model;

class ResidentModel extends Model
{
    protected $table = 'residents';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'first_name', 'last_name', 'address', 'phone', 'email', 'gender', 'birthdate', 'ip_address',    // ✅ new field
        'mac_address' 
    ];
    protected $useTimestamps = true;
}
