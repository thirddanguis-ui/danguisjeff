<?php

namespace App\Models;

use CodeIgniter\Model;

class SettingsModel extends Model
{
    protected $table = 'settings';
    protected $allowedFields = ['name', 'value'];

    public function getMaintenanceStatus()
    {
        $row = $this->where('name', 'maintenance_mode')->first();
        return $row ? $row['value'] : 'off';
    }

    public function toggleMaintenance($status)
    {
        return $this->where('name', 'maintenance_mode')
                    ->set(['value' => $status])
                    ->update();
    }
}
