<?php

namespace App\Models;

use CodeIgniter\Model;

class RequestModel extends Model
{
    protected $table = 'requests';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'resident_id', 'title', 'description', 'priority', 
        'status', 'assigned_to', 'ip_address', 'mac_address'
    ];

    // ❌ Disable timestamps (no created_at, updated_at columns)
    protected $useTimestamps = false;
}
