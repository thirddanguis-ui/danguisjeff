<?php

namespace App\Models;

use CodeIgniter\Model;

class HelperModel extends Model
{
    protected $table = 'helpers';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'fullname',
        'position',
        'contact',
        'email',
        'status',
        'created_at'
    ];
}
