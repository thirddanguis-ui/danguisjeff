<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
// use App\Models\SettingsModel;

class MaintenanceFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $uri = service('uri');
        $segment = strtolower($uri->getSegment(1) ?? '');
        
        // NEVER block admin, auth, dashboard, or maintenance routes
        $protectedSegments = ['admin', 'auth', 'dashboard', 'maintenance'];
        
        if (in_array($segment, $protectedSegments)) {
            // These routes are ALWAYS allowed, skip maintenance check
            return;
        }

        // Get maintenance status from JSON file
        $file = WRITEPATH . 'maintenance_mode.json';
        $maintenanceOn = false;
        
        if (file_exists($file)) {
            $data = json_decode(file_get_contents($file), true);
            $maintenanceOn = isset($data['status']) && $data['status'] === 'on';
        }

        // If maintenance is OFF, allow everything
        if (!$maintenanceOn) {
            return;
        }

        // If maintenance is ON and route is not protected, block it
        return redirect()->to(base_url('maintenance'));
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
