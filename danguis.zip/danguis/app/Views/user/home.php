<?php if ($maintenance_status === 'on'): ?>
    <!-- Maintenance Mode - Show Only Warning -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-warning shadow-lg" style="border-width: 3px !important;">
                    <div class="card-body text-center p-5">
                        <i class="bi bi-exclamation-triangle-fill" style="font-size: 4rem; color: #ff9800;"></i>
                        <h2 class="card-title mt-4 mb-3" style="color: #ff9800;">System Under Maintenance</h2>
                        <p class="card-text lead mb-4" style="color: #555;">
                            We're currently performing scheduled maintenance to improve your experience.
                        </p>
                        <p class="card-text text-muted mb-4">
                            The system will be back online shortly. Thank you for your patience!
                        </p>
                        <a href="<?= base_url('user/logout') ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php else: ?>
    <!-- Normal Mode - Show All Data -->
    <div class="container py-5">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mb-4">Welcome, <?= esc(session('username')) ?> 👋</h2>

                <!-- System Status Card -->
                <div class="card shadow-sm border-0 rounded-3 p-4 mb-4">
                    <h5 class="fw-semibold mb-3">
                        <i class="bi bi-gear-fill text-success me-2"></i>System Status
                    </h5>
                    <div class="alert alert-success" role="alert">
                        <strong>🟩 System Online</strong>
                        <p class="mb-0 mt-2">The system is running normally. All services are available.</p>
                    </div>
                </div>

                <!-- Recent Admin Activity Log -->
                <div class="card shadow-sm border-0 rounded-3 p-4 mb-4">
                    <h5 class="fw-semibold mb-3">
                        <i class="bi bi-clock-history text-info me-2"></i>Recent Admin Updates
                    </h5>

                    <?php if (empty($activityLogs)): ?>
                        <div class="alert alert-secondary">No admin activity yet.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Admin</th>
                                        <th>Action</th>
                                        <th>IP Address</th>
                                        <th>Timestamp</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($activityLogs as $log): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-primary"><?= esc($log['admin_name'] ?? ($log['username'] ?? ($log['user_name'] ?? 'System'))) ?></span>
                                            </td>
                                            <td><?= esc($log['action'] ?? ($log['activity'] ?? '')) ?></td>
                                            <td><small><?= esc($log['ip_address'] ?? ($log['ip'] ?? 'N/A')) ?></small></td>
                                            <td><small class="text-muted"><?= esc($log['created_at'] ?? ($log['timestamp'] ?? '')) ?></small></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- User Actions -->
                <div class="card shadow-sm border-0 rounded-3 p-4">
                    <h5 class="fw-semibold mb-3">
                        <i class="bi bi-person-fill text-secondary me-2"></i>Account
                    </h5>
                    <a href="<?= base_url('user/logout') ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-box-arrow-right me-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
