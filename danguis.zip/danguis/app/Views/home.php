<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Helper - Welcome</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container-welcome {
            max-width: 1000px;
            width: 100%;
        }
        
        .header {
            text-align: center;
            color: white;
            margin-bottom: 50px;
        }
        
        .header h1 {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header p {
            font-size: 1.3rem;
            opacity: 0.95;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }
        
        .login-options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .login-card {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .login-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 50px rgba(0,0,0,0.25);
        }
        
        .card-icon {
            font-size: 3.5rem;
            margin-bottom: 20px;
            display: block;
        }
        
        .card-resident .card-icon {
            color: #667eea;
        }
        
        .card-admin .card-icon {
            color: #764ba2;
        }
        
        .login-card h2 {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 10px;
            color: #333;
        }
        
        .login-card p {
            color: #666;
            margin-bottom: 25px;
            font-size: 0.95rem;
            line-height: 1.5;
        }
        
        .btn-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .btn-login {
            padding: 12px 20px;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1rem;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .card-resident .btn-login-primary {
            background-color: #667eea;
            color: white;
        }
        
        .card-resident .btn-login-primary:hover {
            background-color: #5568d3;
            color: white;
            transform: translateX(5px);
        }
        
        .card-resident .btn-login-secondary {
            background-color: #f0f0f0;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        .card-resident .btn-login-secondary:hover {
            background-color: #667eea;
            color: white;
            transform: translateX(5px);
        }
        
        .card-admin .btn-login-primary {
            background-color: #764ba2;
            color: white;
        }
        
        .card-admin .btn-login-primary:hover {
            background-color: #63408a;
            color: white;
            transform: translateX(5px);
        }
        
        .card-admin .btn-login-secondary {
            background-color: #f0f0f0;
            color: #764ba2;
            border: 2px solid #764ba2;
        }
        
        .card-admin .btn-login-secondary:hover {
            background-color: #764ba2;
            color: white;
            transform: translateX(5px);
        }
        
        .footer-link {
            text-align: center;
            color: white;
            margin-top: 30px;
        }
        
        .footer-link a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            transition: opacity 0.3s ease;
        }
        
        .footer-link a:hover {
            opacity: 0.8;
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .login-options {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .header h1 {
                font-size: 2.5rem;
            }
            
            .login-card {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container-welcome">
        <!-- Header -->
        <div class="header">
            <h1><i class="bi bi-house-heart me-2"></i>Community Helper</h1>
            <p>Connecting residents with support and care</p>
        </div>

        <!-- Login Options -->
        <div class="login-options">
            <!-- Resident/User Login -->
            <div class="login-card card-resident">
                <i class="bi bi-person-circle card-icon"></i>
                <h2>Resident / User</h2>
                <p>Access your community updates, submit help requests, and stay informed.</p>
                <div class="btn-group">
                    <a href="<?= base_url('user/login') ?>" class="btn-login btn-login-primary">
                        <i class="bi bi-box-arrow-in-right"></i>Login as User
                    </a>
                    <a href="<?= base_url('user/register') ?>" class="btn-login btn-login-secondary">
                        <i class="bi bi-person-plus"></i>Register as User
                    </a>
                </div>
            </div>

            <!-- Admin Login -->
            <div class="login-card card-admin">
                <i class="bi bi-shield-lock card-icon"></i>
                <h2>Administrator</h2>
                <p>Manage residents, requests, events, and system settings.</p>
                <div class="btn-group">
                    <a href="<?= base_url('admin/login') ?>" class="btn-login btn-login-primary">
                        <i class="bi bi-box-arrow-in-right"></i>Login as Admin
                    </a>
                    <a href="<?= base_url('admin/register') ?>" class="btn-login btn-login-secondary">
                        <i class="bi bi-person-plus"></i>Register as Admin
                    </a>
                </div>
            </div>
        </div>

        <!-- Public Access -->
        <div class="footer-link">
            <a href="<?= base_url('public') ?>">
                <i class="bi bi-eye me-1"></i>View Public Help Requests (No Login Required)
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>