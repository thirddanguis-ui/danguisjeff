<div class="container mt-4">
    <h2>Community Helpers</h2>
    <a href="<?= base_url('helpers/create') ?>" class="btn btn-primary mb-3">Add New Helper</a>

    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Position</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($helpers)): ?>
                <?php foreach ($helpers as $helper): ?>
                    <tr>
                        <td><?= esc($helper['id']) ?></td>
                        <td><?= esc($helper['fullname']) ?></td>
                        <td><?= esc($helper['position']) ?></td>
                        <td><?= esc($helper['contact']) ?></td>
                        <td><?= esc($helper['email']) ?></td>
                        <td><?= esc($helper['status']) ?></td>
                        <td>
                            <a href="<?= base_url('helpers/edit/' . $helper['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="<?= base_url('helpers/delete/' . $helper['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this helper?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="7" class="text-center">No helpers found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
