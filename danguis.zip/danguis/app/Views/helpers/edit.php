<div class="container mt-4">
    <h2>Edit Helper</h2>
    <form action="<?= base_url('helpers/update/' . $helper['id']) ?>" method="post">
        <div class="mb-3">
            <label>Full Name</label>
            <input type="text" name="fullname" value="<?= esc($helper['fullname']) ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Position</label>
            <input type="text" name="position" value="<?= esc($helper['position']) ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Contact</label>
            <input type="text" name="contact" value="<?= esc($helper['contact']) ?>" class="form-control">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" value="<?= esc($helper['email']) ?>" class="form-control">
        </div>
        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select">
                <option <?= $helper['status'] == 'Active' ? 'selected' : '' ?>>Active</option>
                <option <?= $helper['status'] == 'Inactive' ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>
        <button class="btn btn-primary">Update</button>
        <a href="<?= base_url('helpers') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
