<div class="container mt-4">
    <h2>Add New Helper</h2>
    <form action="<?= base_url('helpers/store') ?>" method="post">
        <div class="mb-3">
            <label>Full Name</label>
            <input type="text" name="fullname" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Position</label>
            <input type="text" name="position" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Contact</label>
            <input type="text" name="contact" class="form-control">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control">
        </div>
        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select>
        </div>
        <button class="btn btn-success">Save</button>
        <a href="<?= base_url('helpers') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
