<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg border-0 rounded-3">
                <div class="card-body p-5">
                    <h3 class="text-center mb-1">
                        <i class="bi bi-shield-lock text-warning me-2"></i>Admin Login
                    </h3>
                    <p class="text-center text-muted mb-4">Enter your credentials</p>

                    <?php if(session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                    <?php endif; ?>

                    <?php if(isset($validation)): ?>
                        <div class="alert alert-danger"><?= $validation->listErrors() ?></div>
                    <?php endif; ?>

                    <form action="<?= base_url('admin/authenticate') ?>" method="post">
                        <div class="mb-3">
                            <label class="form-label">Username or Email</label>
                            <input type="text" name="identity" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Login
                        </button>
                    </form>

                    <hr>
                    <p class="text-center mb-2">Don't have an account?</p>
                    <a href="<?= base_url('admin/register') ?>" class="btn btn-outline-primary w-100">Register as Admin</a>
                    
                    <hr>
                    <p class="text-center text-muted mb-0">
                        <small><a href="<?= base_url('/') ?>" style="text-decoration: none;">← Back to Home</a></small>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
