<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Resident</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:600px;">
    <h4>Edit Resident</h4>
    <form action="<?= base_url('residents/update/'.$resident['id']) ?>" method="post">
        <div class="mb-3">
            <label>First Name</label>
            <input type="text" name="first_name" class="form-control" value="<?= $resident['first_name'] ?>" required>
        </div>
        <div class="mb-3">
            <label>Last Name</label>
            <input type="text" name="last_name" class="form-control" value="<?= $resident['last_name'] ?>" required>
        </div>
        <div class="mb-3">
            <label>Address</label>
            <textarea name="address" class="form-control" required><?= $resident['address'] ?></textarea>
        </div>
        <div class="mb-3">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= $resident['phone'] ?>">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= $resident['email'] ?>">
        </div>
        <div class="mb-3">
            <label>Gender</label>
            <select name="gender" class="form-select">
                <option <?= ($resident['gender'] == 'Male') ? 'selected' : '' ?>>Male</option>
                <option <?= ($resident['gender'] == 'Female') ? 'selected' : '' ?>>Female</option>
                <option <?= ($resident['gender'] == 'Other') ? 'selected' : '' ?>>Other</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Birthdate</label>
            <input type="date" name="birthdate" class="form-control" value="<?= $resident['birthdate'] ?>">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?= base_url('residents') ?>" class="btn btn-secondary">Back</a>
    </form>
</div>
</body>
</html>
