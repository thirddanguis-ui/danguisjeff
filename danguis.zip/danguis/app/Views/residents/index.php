<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Residents</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php
// ✅ Detect both Ethernet and Wi-Fi IPv4 addresses (for display only)
function getNetworkIPs() {
    $output = shell_exec('ipconfig');
    $ethernetIp = '';
    $wifiIp = '';

    // Ethernet IPv4
    if (preg_match('/Ethernet adapter.*?IPv4 Address[.\s]*:\s*([0-9\.]+)/is', $output, $ethMatch)) {
        $ethernetIp = trim($ethMatch[1]);
    }

    // Wi-Fi IPv4
    if (preg_match('/Wireless LAN adapter Wi-Fi.*?IPv4 Address[.\s]*:\s*([0-9\.]+)/is', $output, $wifiMatch)) {
        $wifiIp = trim($wifiMatch[1]);
    }

    return [
        'ethernet' => $ethernetIp ?: 'Not connected',
        'wifi'     => $wifiIp ?: 'Not connected',
    ];
}

$network = getNetworkIPs();
?>

<div class="container mt-4">
    <h3 class="mb-4 fw-bold">Residents List</h3>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <div class="d-flex align-items-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="green" class="me-2 mt-1" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM7 11l5-5-1.5-1.5L7 8l-1.5-1.5L4 8l3 3z"/>
                </svg>
                <div>
                    <strong><?= esc(session()->getFlashdata('success')) ?></strong><br>
                    <small class="text-muted">
                        🖥️ Ethernet IP: <strong><?= $network['ethernet'] ?></strong><br>
                        📶 Wi-Fi IP: <strong><?= $network['wifi'] ?></strong>
                    </small>
                </div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <a href="<?= base_url('residents/create') ?>" class="btn btn-primary mb-3">Add Resident</a>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-bordered table-striped mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>IP Address</th>   <!-- ✅ Added -->
                        <th>MAC Address</th>  <!-- ✅ Added -->
                        <th style="width: 150px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($residents)): ?>
                        <?php foreach ($residents as $r): ?>
                            <tr>
                                <td><?= esc($r['id']) ?></td>
                                <td><?= esc($r['first_name'] . ' ' . $r['last_name']) ?></td>
                                <td><?= esc($r['address']) ?></td>
                                <td><?= esc($r['phone']) ?></td>
                                <td><?= esc($r['email']) ?></td>
                                <td><?= esc($r['ip_address'] ?? '—') ?></td>   <!-- ✅ Fixed variable -->
                                <td><?= esc($r['mac_address'] ?? '—') ?></td>  <!-- ✅ Fixed variable -->
                                <td>
                                    <a href="<?= base_url('residents/edit/' . $r['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('residents/delete/' . $r['id']) ?>"
                                       onclick="return confirm('Delete this resident?')"
                                       class="btn btn-sm btn-danger">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">No residents found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
