<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f5f7fa;
    }
    .sidebar {
      height: 100vh;
      width: 230px;
      position: fixed;
      background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
      color: white;
      padding-top: 20px;
      box-shadow: 2px 0 10px rgba(0,0,0,0.1);
      overflow-y: auto;
    }
    .sidebar h4 {
      font-weight: 700;
      letter-spacing: 0.5px;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 12px 20px;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
    }
    .sidebar a:hover {
      background: rgba(255,255,255,0.15);
      border-left-color: #fff;
      padding-left: 22px;
    }
    .content {
      margin-left: 230px;
      padding: 30px;
      min-height: 100vh;
    }
    .welcome-card {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 12px;
      padding: 25px;
      margin-bottom: 30px;
      box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
    }
    .welcome-card h3 {
      font-weight: 700;
      margin-bottom: 5px;
    }
    .maintenance-card {
      background: white;
      border: 2px solid #ffc107;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 25px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    }
    .maintenance-card h5 {
      font-weight: 700;
      color: #333;
      margin-bottom: 15px;
    }
    .form-switch .form-check-input {
      width: 3rem;
      height: 1.5rem;
      cursor: pointer;
    }
    .form-check-label {
      cursor: pointer;
      margin-left: 10px;
    }
    .status-badge {
      display: inline-block;
      padding: 6px 12px;
      border-radius: 20px;
      font-weight: 600;
      font-size: 14px;
    }
    .status-online {
      background-color: #d4edda;
      color: #155724;
    }
    .status-maintenance {
      background-color: #f8d7da;
      color: #721c24;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h4 class="text-center mb-4">
      <i class="bi bi-house-fill me-2"></i>Community Helper
    </h4>
    <a href="<?= base_url('dashboard') ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
    <a href="<?= base_url('residents') ?>"><i class="bi bi-people-fill me-2"></i>Residents</a>
    <a href="<?= base_url('requests') ?>"><i class="bi bi-chat-left-text me-2"></i>Help Requests</a>
    <a href="<?= base_url('events') ?>"><i class="bi bi-calendar-event me-2"></i>Events</a>
    <a href="<?= base_url('networklogs') ?>"><i class="bi bi-diagram-3 me-2"></i>Network Logs</a>
    <hr style="background-color: rgba(255,255,255,0.2); border: 0; height: 1px; margin: 15px 0;">
    <a href="<?= base_url('logout') ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
  </div>

  <div class="content">
    <!-- Welcome Card -->
    <div class="welcome-card">
      <h3><i class="bi bi-hand-thumbs-up me-2"></i>Welcome, <?= session('username') ?></h3>
      <p class="mb-0">Manage your community efficiently from this dashboard.</p>
    </div>

    <!-- 🛠 Maintenance Mode Toggle -->
    <div class="maintenance-card">
      <h5>
        <i class="bi bi-gear-fill text-warning me-2"></i>System Maintenance Mode
      </h5>
      <form method="post" action="<?= base_url('dashboard/toggleMaintenance') ?>" class="d-flex align-items-center">
        <div class="form-check form-switch">
          <input 
              class="form-check-input" 
              type="checkbox" 
              id="maintenanceToggle" 
              name="maintenance_mode" 
              value="on"
              <?= ($maintenance_status === 'on') ? 'checked' : '' ?>
              onchange="this.form.submit()"
          >
          <label class="form-check-label" for="maintenanceToggle">
            <?php if ($maintenance_status === 'on'): ?>
              <span class="status-badge status-maintenance">
                <i class="bi bi-exclamation-circle me-1"></i>System Under Maintenance
              </span>
            <?php else: ?>
              <span class="status-badge status-online">
                <i class="bi bi-check-circle me-1"></i>System Online
              </span>
            <?php endif; ?>
          </label>
        </div>
      </form>
      <small class="text-muted d-block mt-3">
        <i class="bi bi-info-circle me-1"></i>Toggle to switch between <strong>Online</strong> and <strong>Under Maintenance</strong> mode. 
        Users will be blocked during maintenance.
      </small>
    </div>

    <!-- Content Placeholder -->
    <div class="card border-0 shadow-sm rounded-3 p-4">
      <h5 class="fw-semibold mb-3">
        <i class="bi bi-info-circle text-info me-2"></i>Dashboard Overview
      </h5>
      <p class="text-muted mb-0">
        Select a menu from the sidebar to manage residents, help requests, events, and network logs.
      </p>
    </div>
  </div>
</body>
</html>
