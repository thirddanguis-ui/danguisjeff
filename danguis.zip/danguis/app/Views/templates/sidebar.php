<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Community Helper Management System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f3f6fa;
        }

        .wrapper {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #007bff, #0056b3);
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding-top: 70px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease-in-out;
        }

        .sidebar h4 {
            text-align: center;
            font-weight: 700;
            color: #fff;
            margin-bottom: 25px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 6px;
        }

        .sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 22px;
            color: rgba(255,255,255,0.9);
            text-decoration: none;
            font-weight: 500;
            border-left: 4px solid transparent;
            transition: all 0.2s ease-in-out;
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: rgba(255,255,255,0.1);
            color: #fff;
            border-left: 4px solid #fff;
        }

        /* Topbar */
        .topbar {
            background-color: #ffffff;
            color: #333;
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            z-index: 1000;
        }

        .topbar h5 {
            font-weight: 600;
            margin: 0;
        }

        .topbar a {
            color: #007bff;
            margin-left: 15px;
            text-decoration: none;
            font-weight: 500;
        }

        .topbar a:hover {
            text-decoration: underline;
        }

        /* Content */
        .content {
            margin-left: 250px;
            padding: 80px 30px 30px 30px;
            width: 100%;
        }

        @media (max-width: 992px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding-top: 20px;
            }

            .topbar {
                left: 0;
            }

            .content {
                margin-left: 0;
                padding: 70px 15px;
            }
        }
    </style>
</head>

<body>

<div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
        <h4><i class="bi bi-hand-thumbs-up-fill me-1"></i> Community Helper</h4>
        <ul>
            <li><a href="<?= base_url('dashboard') ?>" class="<?= (uri_string() === 'dashboard') ? 'active' : '' ?>"><i class="bi bi-house-door-fill"></i> Dashboard</a></li>
            <li><a href="<?= base_url('residents') ?>" class="<?= (uri_string() === 'residents') ? 'active' : '' ?>"><i class="bi bi-people-fill"></i> Residents</a></li>
            <li><a href="<?= base_url('requests') ?>" class="<?= (uri_string() === 'requests') ? 'active' : '' ?>"><i class="bi bi-life-preserver"></i> Help Requests</a></li>
            <li><a href="<?= base_url('events') ?>" class="<?= (uri_string() === 'events') ? 'active' : '' ?>"><i class="bi bi-calendar-event-fill"></i> Events</a></li>
            <li><a href="<?= base_url('networklogs') ?>" class="<?= (uri_string() === 'networklogs') ? 'active' : '' ?>"><i class="bi bi-globe"></i> Network Logs</a></li>
            <li><a href="<?= base_url('logout') ?>"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Topbar -->
    <div class="topbar">
        <h5>Welcome, Admin 👋</h5>
        <div>
            <a href="<?= base_url('dashboard') ?>">Dashboard</a>
            <a href="<?= base_url('logout') ?>">Logout</a>
        </div>
    </div>

    <!-- Content -->
    <div class="content">
