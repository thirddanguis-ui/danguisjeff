<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h3 class="card-title mb-3">Public Help Requests</h3>
                    <p class="text-muted">This page shows recent help requests with minimal resident contact info. Admins control maintenance mode.</p>

                    <?php if (empty($requests)) : ?>
                        <div class="alert alert-secondary">No help requests right now.</div>
                    <?php else : ?>
                        <div class="list-group">
                            <?php foreach ($requests as $r) : ?>
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1"><?= esc($r['title']) ?></h5>
                                        <small class="text-muted"><?= esc($r['priority'] ?? 'normal') ?></small>
                                    </div>
                                    <p class="mb-1 text-truncate"><?= esc($r['description']) ?></p>
                                    <small class="text-muted">Resident: <?= esc($r['first_name'] . ' ' . $r['last_name']) ?>
                                        | Phone: <?= esc($r['phone'] ?? 'N/A') ?>
                                        | Email: <?= esc($r['email'] ?? 'N/A') ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
