<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Under Maintenance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
    <div class="text-center">
        <h1 class="display-4 text-warning mb-3">🚧 System Under Maintenance</h1>
        <p class="lead text-muted">We’re performing updates. Please check back later.</p>
    </div>
</body>
</html>
