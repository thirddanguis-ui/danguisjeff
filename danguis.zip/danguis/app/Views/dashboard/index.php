<div class="container-fluid py-4" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
    
    <!-- 🛠 Maintenance Mode Toggle -->
    <div class="card border-0 shadow-sm rounded-3 p-4 mb-4" style="border-left: 4px solid #ffc107;">
        <h5 class="fw-semibold mb-3 text-dark">
            <i class="bi bi-gear-fill text-warning me-2"></i>System Maintenance Mode
        </h5>
        <form method="post" action="<?= base_url('dashboard/toggleMaintenance') ?>">
            <div class="form-check form-switch">
                <input 
                    class="form-check-input" 
                    type="checkbox" 
                    id="maintenanceToggle" 
                    name="maintenance_mode" 
                    value="on"
                    <?= (isset($maintenance_status) && $maintenance_status === 'on') ? 'checked' : '' ?>
                    onchange="this.form.submit()"
                >
                <label class="form-check-label fw-semibold" for="maintenanceToggle">
                    <?php 
                        if (isset($maintenance_status) && $maintenance_status === 'on') {
                            echo '<span class="text-danger"><i class="bi bi-exclamation-circle me-1"></i>🟥 System Under Maintenance</span>';
                        } else {
                            echo '<span class="text-success"><i class="bi bi-check-circle me-1"></i>🟩 System Online</span>';
                        }
                    ?>
                </label>
            </div>
        </form>
        <small class="text-muted d-block mt-2">
            Toggle to switch between <strong>Online</strong> and <strong>Under Maintenance</strong> mode. Users will be blocked during maintenance.
        </small>
    </div>

    <!-- Dashboard Overview -->
    <div class="mb-4">
        <h2 class="fw-bold text-dark mb-2">📊 Dashboard Overview</h2>
        <p class="text-secondary">Monitor residents, help requests, and events with real-time insights.</p>
    </div>

    <!-- Quick Stats -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-lg rounded-3 p-4 text-center bg-primary text-white">
                <div class="fs-1 mb-2"><i class="bi bi-people"></i></div>
                <h5>Total Residents</h5>
                <h3 class="fw-bold"><?= $totalResidents ?></h3>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-lg rounded-3 p-4 text-center bg-danger text-white">
                <div class="fs-1 mb-2"><i class="bi bi-life-preserver"></i></div>
                <h5>Total Help Requests</h5>
                <h3 class="fw-bold"><?= $totalRequests ?></h3>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-lg rounded-3 p-4 text-center bg-success text-white">
                <div class="fs-1 mb-2"><i class="bi bi-calendar-event"></i></div>
                <h5>Total Events</h5>
                <h3 class="fw-bold"><?= $totalEvents ?></h3>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-3 p-4">
                <h5 class="fw-semibold mb-3 text-dark">
                    <i class="bi bi-pie-chart-fill text-primary me-2"></i>
                    Residents Distribution
                </h5>
                <canvas id="residentsChart" height="200"></canvas>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-3 p-4">
                <h5 class="fw-semibold mb-3 text-dark">
                    <i class="bi bi-bar-chart-fill text-success me-2"></i>
                    Monthly Events Overview
                </h5>
                <canvas id="eventsChart" height="200"></canvas>
            </div>
        </div>
    </div>

    <!-- System Overview -->
    <div class="card border-0 shadow-sm rounded-3 p-4 mb-5">
        <h5 class="fw-semibold mb-3 text-dark"><i class="bi bi-info-circle text-secondary me-2"></i>System Overview</h5>
        <p class="text-secondary mb-0">
            The <strong>Community Helper Management System</strong> provides a centralized way for administrators to monitor
            community data, track events, and manage resident help requests efficiently.
            This dashboard offers real-time visual insights to support decision-making and
            improve community engagement.
        </p>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // ✅ Residents Pie Chart
    const residentsCtx = document.getElementById('residentsChart').getContext('2d');
    new Chart(residentsCtx, {
        type: 'pie',
        data: {
            labels: <?= json_encode(array_column($residentsByGender, 'gender')) ?>,
            datasets: [{
                label: 'Residents by Gender',
                data: <?= json_encode(array_column($residentsByGender, 'count')) ?>,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(255, 206, 86, 0.8)'
                ],
                borderWidth: 0
            }]
        },
        options: {
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#333', font: { size: 14 } }
                }
            }
        }
    });

    // ✅ Events Bar Chart
    const eventsCtx = document.getElementById('eventsChart').getContext('2d');
    new Chart(eventsCtx, {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_map(fn($e) => date("F", mktime(0, 0, 0, $e['month'], 1)), $monthlyEvents)) ?>,
            datasets: [{
                label: 'Number of Events',
                data: <?= json_encode(array_column($monthlyEvents, 'count')) ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.85)',
                borderRadius: 6,
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#555', font: { size: 13 } },
                    grid: { color: '#eee' }
                },
                x: {
                    ticks: { color: '#555', font: { size: 13 } },
                    grid: { display: false }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: { backgroundColor: '#333', titleColor: '#fff', bodyColor: '#fff' }
            }
        }
    });
</script>
