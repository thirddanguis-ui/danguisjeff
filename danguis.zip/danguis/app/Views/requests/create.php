<div class="container mt-4">
    <h2>Add New Help Request</h2>
    <form action="<?= base_url('requests/store') ?>" method="post">
        <div class="mb-3">
            <label>Resident</label>
            <select name="resident_id" class="form-select">
                <option value="">-- Select Resident --</option>
                <?php foreach ($residents as $res): ?>
                    <option value="<?= $res['id'] ?>"><?= $res['first_name'] . ' ' . $res['last_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="4" required></textarea>
        </div>
        <div class="mb-3">
            <label>Priority</label>
            <select name="priority" class="form-select">
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select">
                <option>Open</option>
                <option>In Progress</option>
                <option>Resolved</option>
                <option>Closed</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Assigned To</label>
            <input type="text" name="assigned_to" class="form-control">
        </div>
        <button class="btn btn-success">Save</button>
        <a href="<?= base_url('requests') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
