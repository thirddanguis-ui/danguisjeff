<div class="container mt-4">
    <h2>Help Requests</h2>
    <a href="<?= base_url('requests/create') ?>" class="btn btn-primary mb-3">Add New Request</a>

    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Assigned To</th>
                <th>IP Address</th>  <!-- ✅ Added -->
                <th>MAC Address</th> <!-- ✅ Added -->
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($requests)): ?>
                <?php foreach ($requests as $req): ?>
                    <tr>
                        <td><?= esc($req['id']) ?></td>
                        <td><?= esc($req['title']) ?></td>
                        <td><?= esc($req['priority']) ?></td>
                        <td><?= esc($req['status']) ?></td>
                        <td><?= esc($req['assigned_to']) ?></td>
                        <td><?= esc($req['ip_address'] ?? 'N/A') ?></td> <!-- ✅ Fixed variable name -->
                        <td><?= esc($req['mac_address'] ?? 'N/A') ?></td> <!-- ✅ Fixed variable name -->

                        <td>
                            <a href="<?= base_url('requests/edit/' . $req['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="<?= base_url('requests/delete/' . $req['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this request?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="8" class="text-center">No requests found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
