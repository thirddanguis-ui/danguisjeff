<div class="container mt-4">
    <h2>Network Logs</h2>

    <a href="<?= base_url('networklogs/clear') ?>" class="btn btn-danger mb-3" onclick="return confirm('Are you sure you want to clear all logs?')">Clear Logs</a>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Action</th>
                <th>IP Address</th>
                <th>MAC Address</th>
                <th>Date & Time</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= esc($log['id']) ?></td>
                    <td><?= esc($log['admin_name'] ?? ($log['user_name'] ?? 'System')) ?></td>
                    <td><?= esc($log['action']) ?></td>
                    <td><?= esc($log['ip_address']) ?></td>
                    <td><?= esc($log['mac_address']) ?></td>
                    <td><?= date('M d, Y h:i A', strtotime($log['created_at'] ?? $log['timestamp'] ?? 'now')) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
