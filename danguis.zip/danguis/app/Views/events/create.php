<div class="container mt-4">
    <h2>Add New Event</h2>

    <form action="<?= base_url('events/store') ?>" method="post">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label>Location</label>
            <input type="text" name="location" class="form-control">
        </div>

        <div class="mb-3">
            <label>Start Date & Time</label>
            <input type="datetime-local" name="start_datetime" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>End Date & Time</label>
            <input type="datetime-local" name="end_datetime" class="form-control">
        </div>

        <button type="submit" class="btn btn-success">Save Event</button>
        <a href="<?= base_url('events') ?>" class="btn btn-secondary">Back</a>
    </form>
</div>
