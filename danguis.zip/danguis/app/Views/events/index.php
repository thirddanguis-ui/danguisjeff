<div class="container mt-4">
    <h2>Events List</h2>
    <a href="<?= base_url('events/create') ?>" class="btn btn-primary mb-3">+ Add Event</a>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Title</th>
                <th>Location</th>
                <th>Start</th>
                <th>End</th>
                <th>IP Address</th>
                <th>MAC Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($events)): ?>
                <?php foreach ($events as $event): ?>
                    <tr>
                        <td><?= esc($event['title']) ?></td>
                        <td><?= esc($event['location']) ?></td>
                        <td><?= esc($event['start_datetime']) ?></td>
                        <td><?= esc($event['end_datetime']) ?></td>
                        <td><?= esc($event['ip_address'] ?? 'N/A') ?></td>
                        <td><?= esc($event['mac_address'] ?? 'N/A') ?></td>
                        <td>
                            <a href="<?= base_url('events/edit/' . $event['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="<?= base_url('events/delete/' . $event['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this event?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No events found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
