<div class="container mt-4">
    <h2>Edit Event</h2>

    <form action="<?= base_url('events/update/' . $event['id']) ?>" method="post">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" value="<?= esc($event['title']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" required><?= esc($event['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label>Location</label>
            <input type="text" name="location" value="<?= esc($event['location']) ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Start Date & Time</label>
            <input type="datetime-local" name="start_datetime" value="<?= date('Y-m-d\TH:i', strtotime($event['start_datetime'])) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>End Date & Time</label>
            <input type="datetime-local" name="end_datetime" value="<?= date('Y-m-d\TH:i', strtotime($event['end_datetime'])) ?>" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Update Event</button>
        <a href="<?= base_url('events') ?>" class="btn btn-secondary">Back</a>
    </form>
</div>
