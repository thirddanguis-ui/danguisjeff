<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index'); // Landing page with login options

// Maintenance page route
$routes->get('maintenance', function() {
    return view('maintenance_view');
});

// Admin auth routes
$routes->get('admin/login', 'Auth::login');
$routes->get('admin/register', 'Auth::register');
$routes->post('admin/store', 'Auth::store');
$routes->post('admin/authenticate', 'Auth::authenticate');
$routes->get('admin/logout', 'Auth::logout');

// Backwards-compatible logout route (some templates may use /logout)
$routes->get('logout', 'Auth::logout');
$routes->get('dashboard', 'Dashboard::index', ['filter' => 'auth']);

// ✅ Add this POST route for toggling maintenance mode
$routes->post('dashboard/toggleMaintenance', 'Dashboard::toggleMaintenance', ['filter' => 'auth']);

$routes->group('', ['filter' => 'auth'], function($routes) {
    $routes->get('residents', 'Residents::index');
    $routes->get('residents/create', 'Residents::create');
    $routes->post('residents/store', 'Residents::store');
    $routes->get('residents/edit/(:num)', 'Residents::edit/$1');
    $routes->post('residents/update/(:num)', 'Residents::update/$1');
    $routes->get('residents/delete/(:num)', 'Residents::delete/$1');
});

$routes->get('public', 'PublicUser::index');

$routes->get('/requests', 'Requests::index');

// User auth routes (public)
$routes->get('user/register', 'UserAuth::register');
$routes->post('user/store', 'UserAuth::store');
$routes->get('user/login', 'UserAuth::login');
$routes->post('user/auth', 'UserAuth::authenticate');
$routes->get('user/logout', 'UserAuth::logout');

// Protected user area
$routes->get('user/home', 'UserAuth::home', ['filter' => 'userauth']);
$routes->get('/requests/create', 'Requests::create');
$routes->post('/requests/store', 'Requests::store');
$routes->get('/requests/edit/(:num)', 'Requests::edit/$1');
$routes->post('/requests/update/(:num)', 'Requests::update/$1');
$routes->get('/requests/delete/(:num)', 'Requests::delete/$1');

$routes->get('/events', 'Events::index');
$routes->get('/events/create', 'Events::create');
$routes->post('/events/store', 'Events::store');
$routes->get('/events/edit/(:num)', 'Events::edit/$1');
$routes->post('/events/update/(:num)', 'Events::update/$1');
$routes->get('/events/delete/(:num)', 'Events::delete/$1');

$routes->get('/dashboard', 'Dashboard::index');


$routes->get('networklogs', 'NetworkLogs::index');
$routes->get('networklogs/clear', 'NetworkLogs::clear');
