<?php

function checkMaintenanceMode()
{
    // If user is logged in as admin, NEVER block them
    if (session()->get('isLoggedIn')) {
        return; // Admin is logged in, allow access
    }

    $file = WRITEPATH . 'maintenance_mode.json';
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        if (($data['status'] ?? 'off') === 'on') {
            // Maintenance is ON and user is NOT admin, block them
            echo view('maintenance_view');
            exit;
        }
    }
}
