<?php

use App\Models\NetworkLogModel;

if (!function_exists('logNetworkActivity')) {
    function logNetworkActivity($action)
    {
        $logModel = new NetworkLogModel();

        // Get IP address
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

        // Attempt to get MAC (works on LAN or local testing)
        $macAddress = 'UNKNOWN';
        if (stripos(PHP_OS, 'WIN') === 0) {
            @exec('getmac', $mac);
            $macAddress = isset($mac[0]) ? strtok($mac[0], ' ') : 'UNKNOWN';
        } elseif (stripos(PHP_OS, 'LINUX') === 0) {
            @exec('cat /sys/class/net/eth0/address', $mac);
            $macAddress = isset($mac[0]) ? trim($mac[0]) : 'UNKNOWN';
        }

        // Get logged-in user (optional if you have session)
        $session = session();
        $userId = $session->get('user_id') ?? null;

        // Insert log entry
        $logModel->insert([
            'user_id' => $userId,
            'action' => $action,
            'ip_address' => $ipAddress,
            'mac_address' => $macAddress,
        ]);
    }
}
