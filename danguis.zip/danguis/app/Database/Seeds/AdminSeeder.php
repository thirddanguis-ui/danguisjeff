<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AdminSeeder extends Seeder
{
    public function run()
    {
        $password = password_hash('admin123', PASSWORD_BCRYPT); // change password if you like

        $data = [
            'username' => 'admin',
            'email'    => 'admin@example.com',
            'password' => $password,
            'full_name'=> 'System Administrator'
        ];

        // Insert to database
        $this->db->table('admins')->insert($data);

        echo "✅ Admin seeded successfully! Username: admin | Password: admin123\n";
    }
}
